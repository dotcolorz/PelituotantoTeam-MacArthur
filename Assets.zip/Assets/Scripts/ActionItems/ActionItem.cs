using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ActionItem : Interactable
{
  public override void Interact()
    {
        Debug.Log("Interacting with base action Item!");
    }
}
